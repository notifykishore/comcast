# comcast
Here i have captured the reference links that's i have used for implementing the solution:

https://www.tutorialspoint.com/flask/flask_application.htm - used this to understand flask framework
https://pythonguides.com/python-dictionary-length/ - used this for doing manipulation with dictionary
https://docs.python.org/3/library/logging.html - referred this for incorporating logging feature into the application
