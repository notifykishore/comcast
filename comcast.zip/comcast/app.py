from flask import Flask
from flask import request
import logging
import json

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

app = Flask(__name__)

seen_strings = {}


@app.route('/')
def root():
    try:
        return '''
        <pre>
        Welcome to the Stringinator 3000 for all of your string manipulation needs.

        GET / - You're already here!
        POST /stringinate - Get all of the info you've ever wanted about a string. Takes JSON of the following form: {"input":"your-string-goes-here"}
        GET /stats - Get statistics about all strings the server has seen, including the longest and most popular strings.
        </pre>
        '''.strip()
    except Exception as e:
        logger_critical = logging.getLogger()
        logger_critical.setLevel(logging.CRITICAL)
        logger_critical.critical("Exception occured", exc_info=True)
        print("Exception Found in root() function:", e)


@app.route('/stringinate', methods=['GET', 'POST'])
def stringinate():
    try:
        input = ''
        if request.method == 'POST':
            input = request.json['input']
        else:
            input = request.args.get('input', '')
        if input in seen_strings:
            seen_strings[input] += 1
        else:
            seen_strings[input] = 1
        string = input
        frequency_dict = {}
        for character in string:
            if (character==" ") or (character=="!") or (character==".") or (character=="?") or (character==",") or (character==":") or (character==";") or (character=="-") or (character=="'") :
                pass
            elif character in frequency_dict:
                frequency_dict[character] += 1
            else:
                frequency_dict[character] = 1
        #print("frequency_dict=", frequency_dict)
        most_occurring = max(frequency_dict, key=frequency_dict.get)

        return {
            "input": input,
            "length": len(input),
            "Most occuring Character": most_occurring,
            "Occurance Count": frequency_dict[most_occurring]
        }
    except Exception as e:
        logger_critical = logging.getLogger()
        logger_critical.setLevel(logging.CRITICAL)
        logger_critical.critical("Exception occured", exc_info=True)
        logger_critical.setLevel(logging.DEBUG)
        logger_critical.debug("DEBUG", exc_info=True)
@app.route('/stats')
def string_stats():
    try:
        if seen_strings.keys != {}:
            longest_input_received = max({v: len(v) for v in seen_strings.keys()})
        else:
            pass
        #print(longest_input_received)
        return {
            "inputs": seen_strings,
            "longest_input_received": longest_input_received
        }
    except Exception as e:
        logger_critical = logging.getLogger()
        logger_critical.setLevel(logging.CRITICAL)
        logger_critical.critical("Exception occured", exc_info=True)
