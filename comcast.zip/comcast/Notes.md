# comcast

I have used my AWS account to create a ubuntu machine where on top of this, I have installed the provided flask sample application.
Then on the server incorporated the required changes on the app.py file to accomplish below given things:

    1. For the /stringinate endpoint, for a given input string we need to find the character that occurs most frequently and add that character, along with its number of occurrences to the API response JSON. You decide how to represent this in the JSON response. Ignore white space and punctuation.
    
    Json output :
    
        curl -id '{"input":"this is the input"}' -H 'Content-Type: application/json' http://localhost:5000/stringinateHTTP/1.1 200 OK
        Date: Sun, 05 Jun 2022 12:16:25 GMT
        Content-Type: application/json
        Content-Length: 128
        Connection: close

        {
          "Most occuring Character": "t",
          "Occurance Count": 3,
          "input": "this is the input",
          "length": 33
        }
        
        Have added or condition to ignore space and punctuation. And business logic for calculating occurance count and most occuring character can be found in the python file.
        
    2. For the stats endpoint, track which string input is the longest string to be seen by the server and return as the longest_input_received key in the response JSON.
    
    Json output :
    
        curl -H 'Content-Type: application/json' http://localhost:5000/stats
        {
          "inputs": {
            "Kishore": 2, 
            "this is the input": 1
          }, 
          "longest_input_received": "this is the input"
        }
    
    3. Additionally have incorporated logging feature to know what sort of error is being thrown while running into issue.
    
    4. Added try catch block to the existing code as a good practice from the improvement perspective.
    
    
As mentioned in word document have removed venv folder and the dependent libraries and other files.
    
    